/*CREATE SCHEMA torneo_de_futbol;*/
USE torneo_de_futbol;
CREATE TABLE IF NOT EXISTS Persona (
identificacion VARCHAR(50) PRIMARY KEY NOT NULL,
nombre VARCHAR(45),
apellido VARCHAR(45),
fecha_nacimiento DATE
);
INSERT INTO Persona VALUES ('123456','Ronald', 'Koeman','1963-03-21');
INSERT INTO Persona VALUES ('123457','Carlo', 'Ancelotti','1959-06-10');
INSERT INTO Persona VALUES ('123458','Diego', 'Simeone','1970-04-28');
INSERT INTO Persona VALUES ('123459','José', 'Bordalás','1964-03-05');
INSERT INTO Persona VALUES ('0000','Marc-Andre', 'ter Stegen','1992-04-30');
INSERT INTO Persona VALUES ('0001','Gerard', 'Piqué','1987-02-02');
INSERT INTO Persona VALUES ('0002','Sergio', 'Busquets','1988-07-16');
INSERT INTO Persona VALUES ('0003','Antoine', 'Griezmann','1991-03-21');
INSERT INTO Persona VALUES ('0004','Thibaut', 'Courtois','1992-05-11');
INSERT INTO Persona VALUES ('0005','Dani', 'Carvajal','1992-01-11');
INSERT INTO Persona VALUES ('0006','Toni', 'Kroos','1990-01-04');
INSERT INTO Persona VALUES ('0007','Karim', 'Benzema','1987-12-19');
INSERT INTO Persona VALUES ('0008','Jan', 'Oblak','1993-01-07');
INSERT INTO Persona VALUES ('0009','Santiago', 'Arias','1992-01-13');
INSERT INTO Persona VALUES ('0010','Koke', 'Resurrección','1992-01-08');
INSERT INTO Persona VALUES ('0011','Luis', 'Suarez','1987-01-24');
INSERT INTO Persona VALUES ('0012','Jasper', 'Cillesen','1989-04-22');
INSERT INTO Persona VALUES ('0013','Gabriel', 'Paulista','1990-11-26');
INSERT INTO Persona VALUES ('0014','Carlos', 'Soler','1997-01-02');
INSERT INTO Persona VALUES ('0015','Maximiliano', 'Gómez','1996-08-14');












