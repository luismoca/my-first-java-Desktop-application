USE torneo_de_futbol;
/*DROP TABLE Partidos_Equipos;*/
CREATE TABLE IF NOT EXISTS Partidos_Equipos (
Equipo_codigo INT ,
Partido_codigo INT,
es_local  TINYINT,
PRIMARY KEY (Equipo_codigo,Partido_codigo),
FOREIGN KEY (Equipo_codigo) REFERENCES Equipo (identificacion) ,
FOREIGN KEY (Partido_codigo) REFERENCES Partido (codigo)
);
INSERT INTO Partidos_Equipos VALUES (1,0,1);
INSERT INTO Partidos_Equipos VALUES (2,0,0);
INSERT INTO Partidos_Equipos VALUES (3,1,1);
INSERT INTO Partidos_Equipos VALUES (4,1,0);
INSERT INTO Partidos_Equipos VALUES (4,2,1);
INSERT INTO Partidos_Equipos VALUES (2,2,0);
INSERT INTO Partidos_Equipos VALUES (1,3,1);
INSERT INTO Partidos_Equipos VALUES (3,3,0);
INSERT INTO Partidos_Equipos VALUES (2,4,1);
INSERT INTO Partidos_Equipos VALUES (3,4,0);