USE Torneo_de_futbol;
/*SELECT 'Consulta 1';
SELECT nombre ,nombre_estadio,año_fundacion FROM EQUIPO;
SELECT 'Consulta 2';
SELECT nombre , fecha_nacimiento,posicion FROM Persona JOIN Jugador USING(identificacion) WHERE Equipo=3;
SELECT 'Consulta 3';
SELECT codigo,Partido_codigo,minuto,descripcion FROM Gol WHERE minuto>70 ORDER BY minuto DESC;
SELECT 'Consulta 4';
SELECT nombre,apellido FROM Persona JOIN Gol ON Persona.identificacion=Gol.id_Jugador WHERE Partido_codigo=3 ORDER BY minuto;
SELECT 'Consulta 5';
SELECT count(codigo) FROM Partido JOIN Partidos_Equipos ON Partido.codigo=Partidos_Equipos.Partido_codigo WHERE es_local=0 and Equipo_codigo=3;
SELECT 'Consulta 6';
SELECT goles_local,goles_visitante FROM Partido WHERE fecha<'2021-03-27' ORDER BY fecha DESC;*/
SELECT identificacion, nombre,apellido, fecha_nacimiento,posicion,equipo FROM Persona JOIN Jugador USING(identificacion);

