USE torneo_de_futbol;
/*UPDATE Equipo SET nombre_estadio='Wanda' WHERE identificacion=3;
UPDATE Partido SET fecha='2021-04-1 20:00:00' WHERE codigo=4;
DELETE FROM Jugador WHERE identificacion='0009';*/
UPDATE Jugador SET Jugador.equipo=2, posicion='Delantero' WHERE identificacion=0016;