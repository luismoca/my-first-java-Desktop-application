USE torneo_de_futbol;
/*drop table Gol;*/
CREATE TABLE IF NOT EXISTS Gol (
codigo INT ,
minuto INT,
descripcion VARCHAR(45) ,
Partido_codigo INT,
id_Jugador VARCHAR(50),
PRIMARY KEY(codigo,Partido_codigo),
FOREIGN KEY (id_Jugador) REFERENCES Jugador (identificacion) ,
FOREIGN KEY (Partido_codigo) REFERENCES Partido (codigo) 
);
INSERT INTO Gol VALUES (1,15,'Penatil',0,'0003');
INSERT INTO Gol VALUES (2,20,'Tiro libre',0,'0007');
INSERT INTO Gol VALUES (3,85,'Cabeza',0,'0006');
INSERT INTO Gol VALUES (1,70,'Remate larga distancia',1,'0011');
INSERT INTO Gol VALUES (2,84,'Penatil',1,'0011');
INSERT INTO Gol VALUES (1,50,'Tiro libre',2,'0015');
INSERT INTO Gol VALUES (1,43,'Penatil',3,'0010');
INSERT INTO Gol VALUES (2,55,'Remate larga distancia',3,'0002');
INSERT INTO Gol VALUES (3,81,'Tiro libre',3,'0003');