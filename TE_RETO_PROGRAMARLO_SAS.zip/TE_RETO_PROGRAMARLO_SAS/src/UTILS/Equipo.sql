USE torneo_de_futbol;
/*drop table equipo;*/
CREATE TABLE IF NOT EXISTS Equipo (
identificacion INT PRIMARY KEY NOT NULL ,
nombre VARCHAR(45),
ciudad VARCHAR(45),
nombre_estadio VARCHAR(45),
año_fundacion VARCHAR(45),
Director_tecnico  VARCHAR(45),
FOREIGN KEY (Director_tecnico) REFERENCES Director_Tecnico(identificacion) 
);
INSERT INTO Equipo VALUES ('1','Barcelona','Barcelona','Camp Nou','1899','123456');
INSERT INTO Equipo VALUES ('2','Real Madrid','Madrid','Santiago Bernabéu','1902','123457');
INSERT INTO Equipo VALUES ('3','Atlético de Madrid','Madrid','Wanda','1903','123458');
INSERT INTO Equipo VALUES ('4','Valencia','Valencia','Mestalla','1919','123459');