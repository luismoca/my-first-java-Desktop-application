USE torneo_de_futbol;
/*drop table jugador;*/
CREATE TABLE IF NOT EXISTS Jugador (
identificacion VARCHAR(50) PRIMARY KEY,
posicion VARCHAR(45),
equipo INT ,
FOREIGN KEY (identificacion) REFERENCES Persona (identificacion) ,
FOREIGN KEY (equipo) REFERENCES Equipo (identificacion) 
);
INSERT INTO Jugador VALUES ('0000','Portero',1);
INSERT INTO Jugador VALUES ('0001','Defensa',1);
INSERT INTO Jugador VALUES ('0002','Mediocampista',1);
INSERT INTO Jugador VALUES ('0003','Delantero',1);
INSERT INTO Jugador VALUES ('0004','Portero',2);
INSERT INTO Jugador VALUES ('0005','Defensa',2);
INSERT INTO Jugador VALUES ('0006','Mediocampista',2);
INSERT INTO Jugador VALUES ('0007','Delantero',2);
INSERT INTO Jugador VALUES ('0008','Portero',3);
INSERT INTO Jugador VALUES ('0009','Defensa',3);
INSERT INTO Jugador VALUES ('0010','Mediocampista',3);
INSERT INTO Jugador VALUES ('0011','Delantero',3);
INSERT INTO Jugador VALUES ('0012','Portero',4);
INSERT INTO Jugador VALUES ('0013','Defensa',4);
INSERT INTO Jugador VALUES ('0014','Mediocampista',4);
INSERT INTO Jugador VALUES ('0015','Delantero',4);