USE torneo_de_futbol;
/*drop table director_tecnico;*/
CREATE TABLE IF NOT EXISTS Director_Tecnico  (
identificacion VARCHAR(50) PRIMARY KEY,
mes_contrato INT,
año_contrato INT ,
FOREIGN KEY (identificacion) REFERENCES Persona (identificacion)
);
INSERT INTO Director_Tecnico VALUES ('123456',8,2020);
INSERT INTO Director_Tecnico VALUES ('123457',6,2021);
INSERT INTO Director_Tecnico VALUES ('123458',1,2012);
INSERT INTO Director_Tecnico VALUES ('123459',6,2021);