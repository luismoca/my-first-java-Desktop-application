/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLADOR;

import ACCESO.JugadorDAO;
import MODELO.Jugador;
import java.util.ArrayList;

public class JugadorCONTROLADOR {
    public void GuardarJugador(Jugador a){
        JugadorDAO ju= new JugadorDAO();
        ju.crearJugador(a);
        
    }
    public void BorrarJugador(String c){
        JugadorDAO ju= new JugadorDAO();
        ju.eliminarJugador(c);
    }
     
    public ArrayList<Jugador> mostrarJugadores(){
        JugadorDAO ju= new JugadorDAO();
        return ju.ListaJugadores();
    }
    
   public Jugador buscarJugador(String id){
        JugadorDAO ju= new JugadorDAO();
       return ju.buscarJugadorBy_id(id);
      
   }  
    public void actualizarInfJugador(Jugador a){
        JugadorDAO ju= new JugadorDAO();
        ju.actualizarJugador(a);
    }
}

