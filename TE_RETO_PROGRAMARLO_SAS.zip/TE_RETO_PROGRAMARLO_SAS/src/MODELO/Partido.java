/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODELO;

import java.util.Date;

/**
 *
 * @author LUIS HEBERT
 */
public class Partido {
    private int codigo;
    private int goles_local;
    private int goles_visitante;
    private Date fecha;
    
    public Partido(int codigo, int goles_local,int goles_visitante,Date fecha){
        this.codigo=codigo;
        this.goles_local=goles_local;
        this.goles_visitante=goles_visitante;
        this.fecha=fecha;
    }

    /**
     * @return the codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @return the goles_local
     */
    public int getGoles_local() {
        return goles_local;
    }

    /**
     * @param goles_local the goles_local to set
     */
    public void setGoles_local(int goles_local) {
        this.goles_local = goles_local;
    }

    /**
     * @return the goles_visitante
     */
    public int getGoles_visitante() {
        return goles_visitante;
    }

    /**
     * @param goles_visitante the goles_visitante to set
     */
    public void setGoles_visitante(int goles_visitante) {
        this.goles_visitante = goles_visitante;
    }

    /**
     * @return the fecha
     */
    public Date getFecha() {
        return fecha;
    }

    /**
     * @param fecha the fecha to set
     */
    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
}
