/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODELO;

/**
 *
 * @author LUIS HEBERT
 */
public class Partidos_Equipos {
    private int Equipo_codigo;
    private int Partido_codigo;
    private int es_local;

    public Partidos_Equipos(int Equipo_codigo, int Partido_codigo, int es_local) {
        this.Equipo_codigo = Equipo_codigo;
        this.Partido_codigo = Partido_codigo;
        this.es_local = es_local;
    }

    /**
     * @return the Equipo_codigo
     */
    public int getEquipo_codigo() {
        return Equipo_codigo;
    }

    /**
     * @param Equipo_codigo the Equipo_codigo to set
     */
    public void setEquipo_codigo(int Equipo_codigo) {
        this.Equipo_codigo = Equipo_codigo;
    }

    /**
     * @return the Partido_codigo
     */
    public int getPartido_codigo() {
        return Partido_codigo;
    }

    /**
     * @param Partido_codigo the Partido_codigo to set
     */
    public void setPartido_codigo(int Partido_codigo) {
        this.Partido_codigo = Partido_codigo;
    }

    /**
     * @return the es_local
     */
    public int getEs_local() {
        return es_local;
    }

    /**
     * @param es_local the es_local to set
     */
    public void setEs_local(int es_local) {
        this.es_local = es_local;
    }
    
    
    
}
