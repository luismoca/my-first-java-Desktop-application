/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODELO;

/**
 *
 * @author LUIS HEBERT
 */
public class Gol {
    private int codigo;
    private int minuto;
    private String descripcion;
    private int Partido_codigo;
    private int id_jugador;

    public Gol(int codigo, int minuto, String descripcion, int Partido_codigo, int id_jugador) {
        this.codigo = codigo;
        this.minuto = minuto;
        this.descripcion = descripcion;
        this.Partido_codigo = Partido_codigo;
        this.id_jugador = id_jugador;
    }

    /**
     * @return the codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @return the minuto
     */
    public int getMinuto() {
        return minuto;
    }

    /**
     * @param minuto the minuto to set
     */
    public void setMinuto(int minuto) {
        this.minuto = minuto;
    }

    /**
     * @return the descripcion
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * @param descripcion the descripcion to set
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * @return the Partido_codigo
     */
    public int getPartido_codigo() {
        return Partido_codigo;
    }

    /**
     * @param Partido_codigo the Partido_codigo to set
     */
    public void setPartido_codigo(int Partido_codigo) {
        this.Partido_codigo = Partido_codigo;
    }

    /**
     * @return the id_jugador
     */
    public int getId_jugador() {
        return id_jugador;
    }

    /**
     * @param id_jugador the id_jugador to set
     */
    public void setId_jugador(int id_jugador) {
        this.id_jugador = id_jugador;
    }
    
}
