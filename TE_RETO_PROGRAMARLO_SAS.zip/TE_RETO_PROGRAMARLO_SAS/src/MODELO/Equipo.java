/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODELO;

/**
 *
 * @author LUIS HEBERT
 */
public class Equipo {

   
    private int identificacion;
    private String nombre;
    private String ciudad;
    private String nombre_estadio;
    private String año_fundacion;
    private String Director_tecnico;
    
     public Equipo(int identificacion, String nombre, String ciudad, String nombre_estadio, String año_fundacion, String Director_tecnico) {
        this.identificacion = identificacion;
        this.nombre = nombre;
        this.ciudad = ciudad;
        this.nombre_estadio = nombre_estadio;
        this.año_fundacion = año_fundacion;
        this.Director_tecnico = Director_tecnico;
    }

    /**
     * @return the identificacion
     */
    public int getIdentificacion() {
        return identificacion;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the ciudad
     */
    public String getCiudad() {
        return ciudad;
    }

    /**
     * @param ciudad the ciudad to set
     */
    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    /**
     * @return the nombre_estadio
     */
    public String getNombre_estadio() {
        return nombre_estadio;
    }

    /**
     * @param nombre_estadio the nombre_estadio to set
     */
    public void setNombre_estadio(String nombre_estadio) {
        this.nombre_estadio = nombre_estadio;
    }

    /**
     * @return the año_fundacion
     */
    public String getAño_fundacion() {
        return año_fundacion;
    }

    /**
     * @param año_fundacion the año_fundacion to set
     */
    public void setAño_fundacion(String año_fundacion) {
        this.año_fundacion = año_fundacion;
    }

    /**
     * @return the Director_tecnico
     */
    public String getDirector_tecnico() {
        return Director_tecnico;
    }

    /**
     * @param Director_tecnico the Director_tecnico to set
     */
    public void setDirector_tecnico(String Director_tecnico) {
        this.Director_tecnico = Director_tecnico;
    }
    
}
