/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODELO;

/**
 *
 * @author LUIS HEBERT
 */
public class Director_tecnico extends PERSONA{
    
    private  int mes_contrato;
    private int año_contrato;
    
    public Director_tecnico(String identificacion, String nombre, String apellido,String fecha_nacimiento,int mes_contrato,int año_contrato){
        super(identificacion,nombre,apellido,fecha_nacimiento);
        this.mes_contrato=mes_contrato;
        this.año_contrato=año_contrato;
    }

    /**
     * @return the mes_contrato
     */
    public int getMes_contrato() {
        return mes_contrato;
    }

    /**
     * @param mes_contrato the mes_contrato to set
     */
    public void setMes_contrato(int mes_contrato) {
        this.mes_contrato = mes_contrato;
    }

    /**
     * @return the año_contrato
     */
    public int getAño_contrato() {
        return año_contrato;
    }

    /**
     * @param año_contrato the año_contrato to set
     */
    public void setAño_contrato(int año_contrato) {
        this.año_contrato = año_contrato;
    }
    @Override
    public String getIdentificacion() {
        return super.getIdentificacion(); 
      
    }

    @Override
     public String getNombre() {
        return super.getNombre();
    }

   
     
    @Override
    public void setNombre(String nombre) {
        super.setNombre(nombre);
    }

    /**
     * @return the apellido
     */
    @Override
    public String getApellido() {
        return super.getApellido();
    }

    
    @Override
    public void setApellido(String apellido) {
        super.setApellido(apellido);
    }

    
    @Override
    public String getFecha_nacimiento() {
        return super.getFecha_nacimiento();
    }

    
    @Override
    public void setFecha_nacimiento(String fecha_nacimiento) {
        super.setFecha_nacimiento(fecha_nacimiento);
    }
}
