/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODELO;

/**
 *
 * @author LUIS HEBERT
 */
public class Jugador extends PERSONA{
    
    private String posicion;
    private int equipo;
    
    public Jugador (String identificacion , String nombre, String apellido , String fecha_nacimiento, String posicion,int equipo){
        super(identificacion,nombre,apellido,fecha_nacimiento);
        this.posicion=posicion;
        this.equipo=equipo;
    }
    
    /**
     * @return the posicion
     */
    public String getPosicion() {
        return posicion;
    }

    /**
     * @param posicion the posicion to set
     */
    public void setPosicion(String posicion) {
        this.posicion = posicion;
    }

    /**
     * @return the equipo
     */
    public int getEquipo() {
        return equipo;
    }

    /**
     * @param equipo the equipo to set
     */
    public void setEquipo(int equipo) {
        this.equipo = equipo;
    }
   

    @Override
    public String getIdentificacion() {
        return super.getIdentificacion(); 
      
    }

    @Override
     public String getNombre() {
        return super.getNombre();
    }

   
     
    @Override
    public void setNombre(String nombre) {
        super.setNombre(nombre);
    }

    /**
     * @return the apellido
     */
    @Override
    public String getApellido() {
        return super.getApellido();
    }

    
    @Override
    public void setApellido(String apellido) {
        super.setApellido(apellido);
    }

    
    @Override
    public String getFecha_nacimiento() {
        return super.getFecha_nacimiento();
    }

    
    @Override
    public void setFecha_nacimiento(String fecha_nacimiento) {
        super.setFecha_nacimiento(fecha_nacimiento);
    }
}
