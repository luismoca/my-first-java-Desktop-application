/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ACCESO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import MODELO.Jugador;
import UTILS.ConnectionDB;
import java.util.ArrayList;
import java.sql.ResultSet;



public class JugadorDAO {
     private Connection conn = null;
    public void crearJugador(Jugador a){
        
    
        try {
            if(conn == null)
                conn = ConnectionDB.getConnection();
            
            String sql = "INSERT INTO Persona VALUES (?,?,?,?);";
            PreparedStatement statement=conn.prepareStatement(sql);
            statement.setString(1,a.getIdentificacion());
            statement.setString(2,a.getNombre());
            statement.setString(3,a.getApellido());
            statement.setString(4,a.getFecha_nacimiento());
            
            int rowsInserted = statement.executeUpdate();
            if(rowsInserted > 0) 
                JOptionPane.showMessageDialog(null, "La informacion personal fue agregada exitosamente !");
            
            
            sql = "INSERT INTO Jugador VALUES (?,?,?);";
            statement=conn.prepareStatement(sql);
            statement.setString(1,a.getIdentificacion());
            statement.setString(2,a.getPosicion());
            statement.setInt(3,a.getEquipo());
            
            
             rowsInserted = statement.executeUpdate();
            if(rowsInserted > 0) 
                JOptionPane.showMessageDialog(null, "La informacion tecnica fue agregada exitosamente!");
            
            conn.close();
        } 
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Código : " + ex.getErrorCode() 
                                        + "\nError :" + ex.getMessage());
        }
    }
        public void actualizarJugador(Jugador a){
        
        try {
            if(conn == null)
                conn = ConnectionDB.getConnection();
            
            String sql = "UPDATE Persona SET nombre=?,apellido=?,fecha_nacimiento=? WHERE identificacion=?;";
            PreparedStatement statement=conn.prepareStatement(sql);
            statement.setString(1,a.getNombre());
            statement.setString(2,a.getApellido());
            statement.setString(3,a.getFecha_nacimiento());
            statement.setString(4,a.getIdentificacion());
            
            int rowsInserted = statement.executeUpdate();
            if(rowsInserted > 0) 
                JOptionPane.showMessageDialog(null, "La informacion personal fue actualizada exitosamente !");
            
            
            sql = "UPDATE Jugador SET posicion=?,equipo=? WHERE identificacion=?;";
            statement=conn.prepareStatement(sql);
            statement.setString(3,a.getIdentificacion());
            statement.setString(1,a.getPosicion());
            statement.setInt(2,a.getEquipo());
            
            
             rowsInserted = statement.executeUpdate();
            if(rowsInserted > 0) 
                JOptionPane.showMessageDialog(null, "La informacion tecnica fue actualizada exitosamente!");
            
            conn.close();
        } 
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Código : " + ex.getErrorCode() 
                                        + "\nError :" + ex.getMessage());
        }
    }
    public void eliminarJugador(String c){
        
    
        try {
            if(conn == null)
                conn = ConnectionDB.getConnection();
            
            String sql = "DELETE FROM Jugador WHERE identificacion=?;";
            PreparedStatement statement=conn.prepareStatement(sql);
            statement.setString(1,c);
            int rowsInserted = statement.executeUpdate();
            if(rowsInserted > 0) 
                JOptionPane.showMessageDialog(null, "La información Tecnica del Jugador fue eliminada !");
            
            
            sql = "DELETE FROM Persona WHERE identificacion=?;";
            statement=conn.prepareStatement(sql);
            statement.setString(1,c);
            
            
             rowsInserted = statement.executeUpdate();
            if(rowsInserted > 0) 
                JOptionPane.showMessageDialog(null, "La información personal del Jugador fue eliminada!");
            
            conn.close();
        } 
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Código : " + ex.getErrorCode() 
                                        + "\nError :" + ex.getMessage());
        }
        
    }
     public ArrayList<Jugador> ListaJugadores() {
         ArrayList<Jugador> jugadores= new ArrayList<>();
        try {
            if(conn == null)
                conn = ConnectionDB.getConnection();
            
            String sql = "SELECT identificacion, nombre,apellido, fecha_nacimiento,posicion,equipo\n"+
                    "FROM Persona\n"+
                    " JOIN Jugador USING(identificacion);";
            
            
                 PreparedStatement statement=conn.prepareStatement(sql);
                 ResultSet resultado=statement.executeQuery();
                 
                 while(resultado.next())
                         {
                             String identificacion =resultado.getString(1);
                             String nombre =resultado.getString(2);
                             String apellido =resultado.getString(3);
                             String fecha=resultado.getString(4);
                             String posicion =resultado.getString(5);
                             Integer equipo=resultado.getInt(6);
                             Jugador a=new Jugador(identificacion,nombre,apellido,fecha,posicion,equipo);
                             jugadores.add(a);
                             
                         }        
                         
               
            conn.close();
            
        } 
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Código : " + ex.getErrorCode() 
                                        + "\nError :" + ex.getMessage());
        }

    
    return jugadores;
    }
    public Jugador buscarJugadorBy_id(String id) {
         Jugador a=null;
        try {
            if(conn == null)
                conn = ConnectionDB.getConnection();
            
            String sql = "SELECT identificacion, nombre,apellido, fecha_nacimiento,posicion,equipo\n"+
                    "FROM Persona\n"+
                    " JOIN Jugador USING(identificacion) WHERE identificacion=?;";
            
            
                 PreparedStatement statement=conn.prepareStatement(sql);
                 
                 statement.setString(1,id);               
                 ResultSet resultado=statement.executeQuery();
                 
                 if(resultado.next())
                         {
                             String identificacion =resultado.getString(1);
                             String nombre =resultado.getString(2);
                             String apellido =resultado.getString(3);
                             String fecha=resultado.getString(4);
                             String posicion =resultado.getString(5);
                             Integer equipo=resultado.getInt(6);
                             a=new Jugador(identificacion,nombre,apellido,fecha,posicion,equipo);
                             
                             
                         }        
               
                 else{
                     a=new Jugador(null,null,null,null,null,0);
                 }
       
               
            conn.close();
            
        } 
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Código : " + ex.getErrorCode() 
                                        + "\nError :" + ex.getMessage());
        }

    
    return a;
    }
}
    

    
    